package com.cg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bean.UserBean;
import com.cg.exception.AirSpaceException;
import com.cg.service.CustomerServiceImpl;
import com.cg.service.ICustomerService;

/**
 * Servlet implementation class ProcessUser
 */
@WebServlet({"/ProcessUser","/Home","/Register","/PayBill","/Success"})
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getServletPath();
		HttpSession session=request.getSession(true);
		String target="";
		
		if(path.equals("/Home"))
		{
			target="pages/Register.jsp";
		}
		if(path.equals("/Register"))
		{
			ICustomerService service = new CustomerServiceImpl();
			UserBean user = new UserBean();
			
			user.setName(request.getParameter("name"));
			user.setUserName(request.getParameter("userName"));
			user.setMobileNo(request.getParameter("mobileNo"));
			user.setPassword(request.getParameter("password"));
			session.setAttribute("user", user);
			
			try {
				boolean isInserted = service.insertUser(user);
				if(isInserted){
					target="pages/CustomerHome.jsp";
				}
			} catch (AirSpaceException e) {
				request.setAttribute("error", e.getMessage());
				target="pages/Error.jsp";
			}
		}
		
		if(path.equals("/PayBill"))
		{
			target="pages/PayBill.jsp";
		}
		
		if(path.equals("/Success"))
		{
			int amount = Integer.parseInt(request.getParameter("amount"));
			int balanceAmount = 750 - amount;
			request.setAttribute("balance", balanceAmount);
			request.setAttribute("Date", LocalDate.now());
			target="pages/Success.jsp";
		}
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}

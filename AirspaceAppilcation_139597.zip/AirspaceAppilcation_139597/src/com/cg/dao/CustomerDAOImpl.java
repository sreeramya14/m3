package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.bean.UserBean;
import com.cg.exception.AirSpaceException;
import com.cg.util.DBConnection;

public class CustomerDAOImpl implements ICustomerDAO {

	@Override
	public boolean insertUser(UserBean user) throws AirSpaceException {
boolean isInserted = false;
		
		try {
			Connection con = DBConnection.getConnection();
			PreparedStatement st = con.prepareStatement(QueryMapper.INSERT_USER);
			
			st.setString(1, user.getName());
			st.setString(2, user.getUserName());
			st.setString(3, user.getPassword());
			st.setString(4, user.getMobileNo());
			
			int records = st.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			}
		} catch (SQLException e) {
			throw new AirSpaceException(e.getMessage());
		}
		
		return isInserted;
	}

}

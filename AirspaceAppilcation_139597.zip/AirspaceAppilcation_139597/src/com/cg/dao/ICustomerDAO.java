package com.cg.dao;

import com.cg.bean.UserBean;
import com.cg.exception.AirSpaceException;



public interface ICustomerDAO {
	
		public boolean insertUser(UserBean user) throws AirSpaceException;
	}


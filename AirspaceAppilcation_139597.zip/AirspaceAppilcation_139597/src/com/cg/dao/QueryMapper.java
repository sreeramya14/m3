package com.cg.dao;

public interface QueryMapper {
	
	
	public static final String INSERT_USER ="INSERT INTO users VALUES(?,?,?,?)";
	

}

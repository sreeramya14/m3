package com.cg.exception;

public class AirSpaceException extends Exception{
	/**
	 * Author 		: Ramya
	 * Class Name 	: AirSpaceException 
	 * Package 		: com.cg.exception
	 * Date 		: Dec 4, 2017
	 */

	private static final long serialVersionUID = 6528184065712908270L;

	public AirSpaceException(String message) 
	{
		super(message);
	}

}

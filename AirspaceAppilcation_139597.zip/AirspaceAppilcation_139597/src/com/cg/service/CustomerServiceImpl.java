package com.cg.service;


import com.cg.bean.UserBean;
import com.cg.dao.CustomerDAOImpl;
import com.cg.dao.ICustomerDAO;
import com.cg.exception.AirSpaceException;

public class CustomerServiceImpl implements ICustomerService {

	@Override
	public boolean insertUser(UserBean user) throws AirSpaceException {
		ICustomerDAO customerDAO = new CustomerDAOImpl();
		boolean isInserted = customerDAO.insertUser(user);		
		return isInserted;
	}

}

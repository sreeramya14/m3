package com.cg.service;

import com.cg.bean.UserBean;
import com.cg.exception.AirSpaceException;



public interface ICustomerService {
	public boolean insertUser(UserBean user) throws AirSpaceException;

}

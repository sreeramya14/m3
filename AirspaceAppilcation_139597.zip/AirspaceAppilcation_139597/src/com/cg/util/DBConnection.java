package com.cg.util;

import com.cg.exception.AirSpaceException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class DBConnection {
	

	/**
	 * Author 		:RAMYA
	 * Class Name 	: DbConnection
	 * Package 		: com.cg.util
	 * Date 		: DEC 4, 2017
	 */

	
		public static Connection getConnection() throws AirSpaceException {
			Connection conn = null;

			try {
				InitialContext ic = new InitialContext();
				DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
				conn = ds.getConnection();
			}

			catch (SQLException e) {
				throw new AirSpaceException("SQL Error:"+e.getMessage());
			} catch (NamingException e) {
				throw new AirSpaceException("message from DB/NamingExc:"
						+ e.getMessage());
			}
			return conn;
		}
	}




package com.java.cg.msms.dao;

import java.util.ArrayList;

import com.java.cg.msms.dto.TraineeBean;
import com.java.cg.msms.exception.TraineeException;

public interface ModuleDAO {

	public int addDetails(TraineeBean bean) throws TraineeException;
	
	public TraineeBean viewDetails(int id,String moduleName) throws TraineeException;
	
	public ArrayList<Integer> getId() throws TraineeException;
	
}
